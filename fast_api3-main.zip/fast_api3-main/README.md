# Запуск

1. Установите docker - https://www.docker.com/products/docker-desktop/
2. Выполните команду docker compose build
3. Выполните команду docker compose up
4. Откройте браузер по адресу http://127.0.0.1:9000
